package ar.com.edithpernia.proyectobancario.tests;

import ar.com.edithpernia.proyectobancario.entidades.clientes.ClienteEmpresa;
import ar.com.edithpernia.proyectobancario.entidades.cuentas.Cheque;
import ar.com.edithpernia.proyectobancario.entidades.cuentas.CuentaConvertibilidad;

public class TestCuentaConvertibilidad {
    public static void main(String[] args) {

        ClienteEmpresa empresa = new ClienteEmpresa(2, "Globos Almagro", "30-12345678-9");
        System.out.println(empresa);

        CuentaConvertibilidad cuenta = new CuentaConvertibilidad(333333333, empresa, 1000);

      