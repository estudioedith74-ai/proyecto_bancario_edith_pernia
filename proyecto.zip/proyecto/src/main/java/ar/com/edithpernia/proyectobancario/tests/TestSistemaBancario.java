package ar.com.edithpernia.proyectobancario.tests;
 
import ar.com.edithpernia.proyectobancario.entidades.clientes.ClienteEmpresa;
import ar.com.edithpernia.proyectobancario.entidades.clientes.ClienteIndividual;
import ar.com.edithpernia.proyectobancario.entidades.cuentas.CajaAhorro;
import ar.com.edithpernia.proyectobancario.entidades.cuentas.Cheque;
import ar.com.edithpernia.proyectobancario.entidades.cuentas.Cuenta;
import ar.com.edithpernia.proyectobancario.entidades.cuentas.CuentaCorriente;
 
public class TestSistemaBancario {
    public static void main(String[] args) {
 
        // ---------- CLIENTES ----------
        ClienteIndividual Edith = new ClienteIndividual(1, "Edith", "Pernia", "30111222");
        System.out.println(Edith);
 
        ClienteEmpresa empresa = new ClienteEmpresa(2, "Globos Almagro", "30-12345678-9");
        System.out.println(empresa);
 
       
 
        CajaAhorro caja = new CajaAhorro(987654321, Edith, 0.05);
 
       