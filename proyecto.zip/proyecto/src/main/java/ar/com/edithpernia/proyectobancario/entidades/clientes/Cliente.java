package ar.com.edithpernia.proyectobancario.entidades.clientes;
 
import lombok.Getter;
import lombok.ToString;
import lombok.AllArgsConstructor;
 
@Getter
@ToString
@AllArgsConstructor // lo coloque porque es el que me da mi constructor, no necesito escribirlo a mano porque se sobre entiende que él existe

// mi clase es publica porque necesito que sea visible y accesible para todo mi proyecto, 
// por ejemplo para que mis tests u otras clases sepan que existen y puedan crear objetos a partir de ellas
public abstract class Cliente {
 
    // mi atributo es private por el pilar de Encapsulamiento, si lo dejo public me lo pueden modificar.
    // Para mí un número de cliente es una clave de identificador única, por lo que no quiero 
    // permitir que modifiquen el número (por eso omití deliberadamente el @Setter).
    private int nroCliente;
 
}
 